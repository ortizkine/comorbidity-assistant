import Head from 'next/head';
import MedicalComorbidityClassifier from '../components/MedicalComorbidityClassifier';

export default function Home() {
  return (
    <>
      <Head>
        <title>Asistente de Comorbilidades</title>
      </Head>
      <main className="min-h-screen bg-gray-50 p-4">
        <MedicalComorbidityClassifier />
      </main>
    </>
  );
}